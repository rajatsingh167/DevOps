package mypack;

public class Test {
static int a;

Test()
{
	a=34;
}
	public static void main(String[] args) {
		System.out.println(a);

	}

}
