package test;

public class HelloWorld
{
    static public void main(String...args)
    {
       System.out.println("Hello world from Gradle");
    }
}