package com.capgemini.exception;

public class InsufficentInitialAmmountException extends Exception {

}
