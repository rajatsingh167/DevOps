
public class InsufficientBalanceException extends Exception {

}
