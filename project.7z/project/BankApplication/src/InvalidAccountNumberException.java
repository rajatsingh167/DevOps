
public class InvalidAccountNumberException extends Exception {

}
