
public class testjava {

}
