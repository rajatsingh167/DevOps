
public class Test {

	public static void main(String[] args) {
		int a=100;
		int b;
		
		if(true)
		{
			b=100;
		}
		
		
		System.out.println(b);

	}

}
