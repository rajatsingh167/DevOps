package mypack;

public class MainApp {

	public static void main(String[] args) {
		System.out.println("HelloWorld");
		
		System.out.println("Hello world once again");
		
		System.out.println("Sales people");
                System.out.println("Adding new feature");

	}

}
