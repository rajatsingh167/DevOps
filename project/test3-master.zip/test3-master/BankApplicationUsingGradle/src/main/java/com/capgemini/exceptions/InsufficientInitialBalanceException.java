package com.capgemini.exceptions;

public class InsufficientInitialBalanceException extends Exception {

}
