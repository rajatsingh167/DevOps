
public class Test {

	public static void main(String[] args) {
		Integer i=128;
		Integer j=128;
		
		
		if(i==j)
		{
			System.out.println("both are same");
		}

	}

}
